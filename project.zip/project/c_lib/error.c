#include "ticket.h"

static int last_error_code = 0;

void c_set_last_error(int code) {
    last_error_code = code;
}

int c_get_last_error() {
    return last_error_code;
}   