//queue.c
#include "ticket.h"

//최대 큐 크기: 1000개의 Ticket 저장 가능
#define MAX_QUEUE 1000

//Queue 자료구조 정의
//front = 데이터를 꺼낼 위치
//rear  = 데이터를 삽입할 위치
typedef struct {
    int front;
    int rear;
    Ticket data[MAX_QUEUE]; //Ticket 구조체를 통째로 저장
} TicketQueue;

//실제로 사용할 큐 변수 (전역적, 내부에서만 접근)
static TicketQueue queue = { 0, 0 };

/*
=====================================================================
   내부 함수 (Python에서는 직접 접근하지 않음)
=====================================================================
*/


/*
큐 초기화
서버 시작 시 Flask에서 최초 1회 호출예정
*/
void c_init_queue() {
    queue.front = 0;
    queue.rear = 0;
}

/*
큐가 비어있는지 확인
return: 1 (true) / 0 (false)
*/
static int is_empty_queue() {
    return queue.front == queue.rear;
}

/*
큐가 꽉 찼는지 확인
return: 1 (true) / 0 (false)
*/
static int is_full_queue() {
    return (queue.rear + 1) % MAX_QUEUE == queue.front;
}


/*
=====================================================================
    Export 함수 (Python → ctypes로 직접 호출합니다.)
=====================================================================
*/

/*
큐에 Ticket 삽입
rear 위치에 Ticket 저장 후 rear 이동
*/
void c_enqueue_ticket(Ticket t) {
    if (is_full_queue()) {
        c_set_last_error(1); //Queue Full Error
        return;
    }
    queue.data[queue.rear] = t;
    queue.rear = (queue.rear + 1) % MAX_QUEUE;
}

/*
큐에서 Ticket 제거 (FIFO)
front 위치에서 Ticket 꺼내고 front 이동
*/
Ticket c_dequeue_ticket() {
    Ticket empty = { .id = -1 };
    if (is_empty_queue()) {
		c_set_last_error(2); //Queue Empty Error
        return empty;
    }
	c_set_last_error(0); //No Error

    Ticket t = queue.data[queue.front];
    queue.front = (queue.front + 1) % MAX_QUEUE;
    return t;       
}

/*
큐의 맨 앞 Ticket 확인 (삭제 X)
*/
Ticket c_peek_ticket() {
    Ticket empty = { 0 };
    if (is_empty_queue()) return empty;
    return queue.data[queue.front];
}

/*
큐의 특정 ID를 가진 Ticket 제거
return: 1 (성공) / 0 (실패)
*/
int c_remove_from_queue(int id) {
    int size = c_queue_size();
    if (size == 0) return 0;

    Ticket temp[MAX_QUEUE];
    int newRear = 0;

    while (!is_empty_queue()) {
        Ticket t = c_dequeue_ticket();
        if (t.id != id) temp[newRear++] = t;
    }

    queue.front = 0;
    queue.rear = 0;

    for (int i = 0; i < newRear; i++)
        c_enqueue_ticket(temp[i]);

    return 1;
}


/*
큐에 현재 몇 개의 티켓이 들어있는지 확인
*/
int c_queue_size() {
    return (queue.rear - queue.front + MAX_QUEUE) % MAX_QUEUE;
}