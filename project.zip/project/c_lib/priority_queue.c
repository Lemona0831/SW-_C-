//priority_queue.c
#include "ticket.h"

#define MAX_HEAP 1000

typedef struct {
    Ticket heap[MAX_HEAP];
    int size;              
} PriorityQueue;

static PriorityQueue pq = { 0 };

static void swap_ticket(Ticket* a, Ticket* b) {
    Ticket tmp = *a;
    *a = *b;
    *b = tmp;
}

static void heapify_up(int index) {
    while (index > 1) {
        int parent = index / 2;
        if (pq.heap[parent].priority < pq.heap[index].priority) {
            swap_ticket(&pq.heap[parent], &pq.heap[index]);
            index = parent;
        }
        else break;
    }
}

static void heapify_down(int index) {
    while (1) {
        int left = index * 2;
        int right = index * 2 + 1;
        int largest = index;

        if (left <= pq.size && pq.heap[left].priority > pq.heap[largest].priority)
            largest = left;
        if (right <= pq.size && pq.heap[right].priority > pq.heap[largest].priority)
            largest = right;

        if (largest != index) {
            swap_ticket(&pq.heap[index], &pq.heap[largest]);
            index = largest;
        }
        else break;
    }
}

void c_init_priority_queue() {
    pq.size = 0;
}

void c_push_priority(Ticket t) {
    if (pq.size >= MAX_HEAP - 1) {
		c_set_last_error(3); //Priority Queue Full Error
        return;
    }
    pq.heap[++pq.size] = t;    
    heapify_up(pq.size);       
}

Ticket c_pop_priority() {
    Ticket empty = { 0 };
    if (pq.size == 0) {
		c_set_last_error(4); //Priority Queue Empty Error   
        return empty;
    }

    Ticket t = pq.heap[1];              
    pq.heap[1] = pq.heap[pq.size--];    
    heapify_down(1);                    
    return t;
}


Ticket c_peek_priority() {
    Ticket empty = { 0 };
    if (pq.size == 0) return empty;
    return pq.heap[1];
}

Ticket c_get_priority_ticket(int index) {
    if (index < 1 || index > pq.size) {
        Ticket empty = { -1 };
        return empty;
    }
    return pq.heap[index];
}


int c_priority_size() {
    return pq.size;
}