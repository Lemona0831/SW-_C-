//ticket.h
#pragma once
#include <stdio.h>
#include <string.h>

//Ticket Structure
typedef struct {
    int id;
    char user[50];
    char message[256];
    int priority;   // 0=�Ϲ�, 1~5=���
    char created_at[30];
} Ticket;


//Windows/Linux Export Setup
#ifdef _WIN32
#define EXPORT __declspec(dllexport)
#else
#define EXPORT
#endif

#ifdef __cplusplus
extern "C" {
#endif

    //Queue Export Functions
    EXPORT void c_init_queue();
    EXPORT void c_enqueue_ticket(Ticket t);
    EXPORT Ticket c_dequeue_ticket();
    EXPORT Ticket c_peek_ticket();
    EXPORT int c_remove_from_queue(int id);
    EXPORT int c_queue_size();

    //Priority Queue Export Functions;
    EXPORT void c_init_priority_queue();
    EXPORT void c_push_priority(Ticket t);
    EXPORT Ticket c_pop_priority();
    EXPORT Ticket c_peek_priority();
    EXPORT int c_priority_size();
    EXPORT Ticket c_get_priority_ticket(int index);


    //Error State API
    EXPORT void c_set_last_error(int code);
    EXPORT int c_get_last_error();

#ifdef __cplusplus
}
#endif