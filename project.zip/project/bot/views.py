import discord
from discord.ui import View, Modal, TextInput
import math

# =============== 페이지 이동 모달 =============== #
class PageModal(Modal, title="페이지 이동"):
    def __init__(self, view):
        super().__init__()
        self.view = view
        self.page_input = TextInput(label="페이지 번호")
        self.add_item(self.page_input)

    async def on_submit(self, interaction: discord.Interaction):
        try:
            page = int(self.page_input.value)
        except:
            return await interaction.response.send_message(
                "숫자를 입력해 주세요!",
                ephemeral=True
            )
        await interaction.response.defer()
        await self.view.update_page(page)


# ================= 기본 티켓 목록 UI ================= #
class TicketListView(View):
    def __init__(self, tickets, page=1, title="티켓 목록", color=0x1abc9c):
        super().__init__(timeout=300)
        self.tickets = tickets
        self.page = page
        self.title = title
        self.color = color

        self.max_per_page = 10
        self.total_pages = max(1, math.ceil(len(tickets) / self.max_per_page))
        self.message = None

    async def update_page(self, page):
        self.page = max(1, min(page, self.total_pages))
        await self.message.edit(embed=self.build_embed(), view=self)

    def build_embed(self):
        start = (self.page - 1) * self.max_per_page
        page_tickets = self.tickets[start:start + self.max_per_page]

        embed = discord.Embed(
            title=f"{self.title} ({self.page}/{self.total_pages})",
            color=self.color
        )

        for t in page_tickets:
            embed.add_field(
                name=f"🆔 #{t['id']} (우선순위 {t['priority']})",
                value=f"👤 {t['user']}\n💬 {t['message']}\n⏱ {t['created_at']}",
                inline=False
            )
        return embed

    @discord.ui.button(style=discord.ButtonStyle.secondary, emoji="◀")
    async def prev_page(self, interaction: discord.Interaction, button):
        await interaction.response.defer()
        await self.update_page(self.page - 1)

    @discord.ui.button(style=discord.ButtonStyle.primary, emoji="🔢")
    async def input_page(self, interaction: discord.Interaction, button):
        await interaction.response.send_modal(PageModal(self))

    @discord.ui.button(style=discord.ButtonStyle.secondary, emoji="▶")
    async def next_page(self, interaction: discord.Interaction, button):
        await interaction.response.defer()
        await self.update_page(self.page + 1)


# ================= 우선순위 티켓 전용 ================= #
class PriorityTicketListView(TicketListView):
    def __init__(self, tickets):
        super().__init__(
            tickets,
            page=1,
            title="우선순위 티켓 목록",
            color=0xff0000
        )
