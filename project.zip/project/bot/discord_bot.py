import discord
from discord.ext import commands
from ticket_manager import Ticket, lib
from data_manager import load_tickets
from commands_ticket import setup_commands
import os

TOKEN = os.getenv("DISCORD_TOKEN")

bot = commands.Bot(command_prefix="!", intents=discord.Intents.all())

@bot.event
async def on_ready():
    print(f"로그인 성공! {bot.user}")

    lib.c_init_queue()
    lib.c_init_priority_queue()

    # JSON 복원
    data = load_tickets()
    for t in data.get("tickets", []):
        ticket_c = Ticket(
            id=t["id"],
            user=t["user"].encode(),
            message=t["message"].encode(),
            priority=t["priority"],
            created_at=t["created_at"].encode()
        )
        if t["priority"] == 0:
            lib.c_enqueue_ticket(ticket_c)
        else:
            lib.c_push_priority(ticket_c)

    print("JSON → C 복원 완료")

    # Global Sync
    synced = await bot.tree.sync()
    print(f"Global Slash Commands 등록 {len(synced)}개 완료")


setup_commands(bot)
bot.run(TOKEN)
