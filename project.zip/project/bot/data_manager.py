import json
import csv
import os
from datetime import datetime
from ticket_manager import Ticket

TICKET_PATH = "tickets.json"
LOG_PATH = "ticket_logs.csv"

def load_tickets():
    if not os.path.exists(TICKET_PATH):
        with open(TICKET_PATH, "w", encoding="utf-8") as f:
            json.dump({"tickets": []}, f, ensure_ascii=False, indent=4)

    with open(TICKET_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

def save_tickets(data):
    with open(TICKET_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

def save_log(ticket_c: Ticket, processed_by: str):
    log_exists = os.path.exists(LOG_PATH)

    with open(LOG_PATH, "a", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f)

        if not log_exists:
            writer.writerow(["ticket_id", "user", "message",
                             "created_at", "processed_by", "processed_at"])

        writer.writerow([
            ticket_c.id,
            ticket_c.user.decode(),
            ticket_c.message.decode(),
            ticket_c.created_at.decode(),
            processed_by,
            datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        ])
