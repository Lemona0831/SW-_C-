# ticket_manager.py
from ctypes import CDLL, Structure, c_int, c_char
import os

dll_path = os.path.join(os.path.dirname(__file__), "ticketlib.dll")
lib = CDLL(dll_path)

class Ticket(Structure):
    _fields_ = [
        ("id", c_int),
        ("user", c_char * 50),
        ("message", c_char * 256),
        ("priority", c_int),
        ("created_at", c_char * 30),
    ]

# --- 기본 큐 ---
lib.c_init_queue.restype = None
lib.c_enqueue_ticket.argtypes = [Ticket]
lib.c_dequeue_ticket.restype = Ticket
lib.c_peek_ticket.restype = Ticket
lib.c_remove_from_queue.argtypes = [c_int]
lib.c_remove_from_queue.restype = c_int
lib.c_queue_size.restype = c_int

# --- 우선순위 큐 ---
lib.c_init_priority_queue.restype = None
lib.c_push_priority.argtypes = [Ticket]
lib.c_pop_priority.restype = Ticket
lib.c_peek_priority.restype = Ticket
lib.c_priority_size.restype = c_int
lib.c_get_priority_ticket.argtypes = [c_int]
lib.c_get_priority_ticket.restype = Ticket

# --- 에러코드 ---
lib.c_get_last_error.restype = c_int
