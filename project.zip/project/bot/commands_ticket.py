import discord
from discord import app_commands

from ticket_manager import Ticket, lib
from data_manager import load_tickets, save_tickets, save_log
from permissions import is_admin, deny_permission
from views import TicketListView, PriorityTicketListView

def setup_commands(bot: discord.Client):

    # -------------------------------
    # 티켓 개수 확인
    # -------------------------------
    @bot.tree.command(name="ticket_status", description="티켓 수 확인")
    async def ticket_status(interaction: discord.Interaction):
        size = lib.c_queue_size()
        priority = lib.c_priority_size()
        await interaction.response.send_message(
            f"일반 큐: {size} / 우선순위 큐: {priority}",
            ephemeral=True
        )

    # -------------------------------
    # 티켓 생성
    # -------------------------------
    @bot.tree.command(name="ticket_create", description="문의 티켓 생성")
    @app_commands.describe(message="문의 내용을 입력하세요")
    async def ticket_create(interaction: discord.Interaction, message: str):

        data = load_tickets()
        new_id = len(data["tickets"]) + 1

        ticket = {
            "id": new_id,
            "user": str(interaction.user),
            "message": message,
            "priority": 0,
            "created_at": interaction.created_at.strftime("%Y-%m-%d %H:%M:%S")
        }

        data["tickets"].append(ticket)
        save_tickets(data)

        # C 큐 삽입
        ticket_c = Ticket(
            id=new_id,
            user=ticket["user"].encode(),
            message=ticket["message"].encode(),
            priority=0,
            created_at=ticket["created_at"].encode()
        )
        lib.c_enqueue_ticket(ticket_c)

        await interaction.response.send_message(
            f"📨 티켓 #{new_id} 생성 완료!\n💬 `{message}`",
            ephemeral=True
        )

    # -------------------------------
    # 티켓 목록
    # -------------------------------
    @bot.tree.command(name="ticket_list", description="티켓 목록 DM 발송")
    async def ticket_list(interaction: discord.Interaction):

        data = load_tickets()
        tickets = data.get("tickets", [])

        if not is_admin(interaction.user):
            tickets = [
                t for t in tickets if t["user"] == str(interaction.user)
            ]

            if not tickets:
                return await interaction.response.send_message(
                    "📂 조회할 티켓이 없습니다!",
                    ephemeral=True
                )

        await interaction.response.send_message(
            "📩 DM으로 티켓 목록을 전송했습니다!",
            ephemeral=True
        )

        dm = await interaction.user.create_dm()
        view = TicketListView(tickets)
        msg = await dm.send(embed=view.build_embed(), view=view)
        view.message = msg

    # -------------------------------
    # 다음 티켓 처리
    # -------------------------------
    @bot.tree.command(name="ticket_next", description="다음 티켓 처리(Admin only)")
    async def ticket_next(interaction: discord.Interaction):

        if not is_admin(interaction.user):
            return await deny_permission(interaction)

        if lib.c_priority_size() > 0:
            ticket_c = lib.c_pop_priority()
            source = "우선순위 티켓"
        else:
            ticket_c = lib.c_dequeue_ticket()
            source = "일반 티켓"

        if ticket_c.id == -1:
            return await interaction.response.send_message(
                "처리할 티켓이 없습니다.",
                ephemeral=True
            )

        # JSON 삭제
        data = load_tickets()
        data["tickets"] = [
            t for t in data["tickets"] if t["id"] != ticket_c.id
        ]
        save_tickets(data)

        save_log(ticket_c, str(interaction.user))

        embed = discord.Embed(
            title=f"{source} #{ticket_c.id} 처리 완료",
            color=0xe67e22
        )
        embed.add_field(name="👤 사용자", value=ticket_c.user.decode(), inline=False)
        embed.add_field(name="💬 내용", value=ticket_c.message.decode(), inline=False)
        embed.add_field(name="⏱ 생성일", value=ticket_c.created_at.decode(), inline=False)

        await interaction.response.send_message(embed=embed, ephemeral=True)

    # -------------------------------
    # 우선순위 설정
    # -------------------------------
    @bot.tree.command(name="ticket_priority", description="티켓 우선순위 설정(1~5)")
    async def ticket_priority(interaction, ticket_id: int, level: int):

        if not is_admin(interaction.user):
            return await deny_permission(interaction)

        if not (1 <= level <= 5):
            return await interaction.response.send_message(
                "우선순위는 1~5여야 합니다.",
                ephemeral=True
            )

        data = load_tickets()
        found = None

        for t in data["tickets"]:
            if t["id"] == ticket_id:
                found = t
                break

        if not found:
            return await interaction.response.send_message(
                "티켓이 없습니다.",
                ephemeral=True
            )

        # JSON 업데이트
        found["priority"] = level
        save_tickets(data)

        # 기존 큐 제거
        lib.c_remove_from_queue(ticket_id)

        # 우선순위 큐 삽입
        ticket_c = Ticket(
            id=found["id"],
            user=found["user"].encode(),
            message=found["message"].encode(),
            priority=level,
            created_at=found["created_at"].encode()
        )
        lib.c_push_priority(ticket_c)

        await interaction.response.send_message(
            f"티켓 #{ticket_id} → 우선순위 {level}으로 변경되었습니다.",
            ephemeral=True
        )

    # -------------------------------
    # 우선순위 큐 리스트 출력
    # -------------------------------
    # ----- 우선순위 티켓 목록 보기 (Admin only) -----
    @bot.tree.command(name="ticket_priority_list", description="우선순위 티켓 목록 보기 (Admin only)")
    async def ticket_priority_list(interaction: discord.Interaction):

        if not is_admin(interaction.user):
            return await deny_permission(interaction)

        # ✅ JSON에서 우선순위 있는 티켓만 뽑기
        data = load_tickets()
        tickets = [t for t in data.get("tickets", []) if t["priority"] > 0]

        if not tickets:
            return await interaction.response.send_message(
                "우선순위 티켓이 없습니다.",
                ephemeral=True
            )

        # ✅ 우선순위 기준으로 정렬 (priority 내림차순, 같으면 id 오름차순)
        tickets.sort(key=lambda t: (-t["priority"], t["id"]))

        # ✅ DM 안내
        await interaction.response.send_message(
            "🚨 우선순위 티켓 목록을 DM으로 전송했습니다!",
            ephemeral=True
        )

        dm = await interaction.user.create_dm()

        # ✅ PriorityTicketListView 사용
        view = PriorityTicketListView(tickets)
        msg = await dm.send(
            embed=view.build_embed(),
            view=view
        )
        view.message = msg


    # -------------------------------
    # 봇 종료
    # -------------------------------
    @bot.tree.command(name="shutdown", description="봇 종료(Admin only)")
    async def shutdown(interaction):
        if not is_admin(interaction.user):
            return await deny_permission(interaction)

        await interaction.response.send_message("봇 종료 중...", ephemeral=True)
        await bot.close()
