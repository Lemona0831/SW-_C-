import discord

def is_admin(user: discord.User):
    return user.guild_permissions.administrator

async def deny_permission(interaction):
    await interaction.response.send_message(
        "관리자 권한이 필요합니다.",
        ephemeral=True
    )
